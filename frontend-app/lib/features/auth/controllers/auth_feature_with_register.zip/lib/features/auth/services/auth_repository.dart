import '../../../core/services/api_service.dart';
import '../models/login_request.dart';

class AuthRepository {
  final ApiService _api = ApiService();

  Future<String?> login(LoginRequest data) async {
    final response = await _api.post('/auth/login', body: data.toJson());
    if (response.statusCode == 200) {
      return response.data['token'];
    } else {
      throw Exception(response.data['message']);
    }
  }
}

import '../models/register_request.dart';

  Future<String?> register(RegisterRequest data) async {
    final response = await _api.post('/auth/register', body: data.toJson());
    if (response.statusCode == 200) {
      return response.data['token'];
    } else {
      throw Exception(response.data['message']);
    }
  }
